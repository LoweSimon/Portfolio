<?php
// Allow debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Avoid blank line before opening tag
?><!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8"/>
    <title>Block 2 Part 6 PHP Application</title>
    <meta name="author" content="Stephen Rice"/>
  </head>
  <body>
<?php

// SIMPLE DATA ENTRY APPLICATION

// DEPENDS ON:
// connect.php
// Upload and include this file to make a connection to your database.
// credentials.php
// Record your database credentials in this file for use in connect.php.

// ERROR HANDLING:
// If an unexpected error occurs we will simply end the script using die()
// In a real application you might handle errors more elegantly by throwing
// an Exception, logging the error for investigation/monitoring, and showing
// a "friendly" error page instead.


// Reuse code to make a database connection in $db
require 'connect.php';

// Ensure our table exists

// If it exists but with wrong structure, or to brutally delete data, execute:
// mysqli_query($db, 'DROP TABLE b2p6_profile');

// This weird syntax is called "heredoc", it works similarly to """ in Python
$sql = <<< END
CREATE TABLE IF NOT EXISTS b2p6_profile (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
username VARCHAR(15) NOT NULL,
first_name VARCHAR(50) NOT NULL,
last_name VARCHAR(50) NOT NULL,
age TINYINT NULL,
email_address VARCHAR(50) NOT NULL,
password VARCHAR(50) NULL
)
END;
mysqli_query($db, $sql) or die(mysqli_error($db));

?>
    <!-- This CSS is reusable and could be moved to an external file -->
    <style>
      /* Simple initial CSS to present forms more neatly */

      /* Ensure everything has the same font */
      body, input, textarea, select {
        font-family: sans-serif;
        font-size: 14px;
      }

      /* Nicer spacing */
      body {
        padding: 0.5em;
      }
      h1 {
        margin-top: 0;
      }

      /* Limit width of form and centre in page */
      form {
        background-color: #eee;
        padding: 0.5em;
        width: 600px;
        margin: auto;
      }
      fieldset {
        margin-bottom: 0.5em;
      }
      legend {
        font-size: 0.9em;
        font-weight: bold;
      }

      /* Line up labels a bit (use :first-child to only add * to span before each input) */
      label span:first-child {
        display: inline-block;
        min-width: 6em;
      }

      /* Nicer text inputs (use :not() to avoid selecting Submit button) */
      input:not([type="submit"]), textarea {
        border: 2px inset #eee;
        padding: 2px;
      }
      select {
        border: 2px inset #eee;
        padding: 1px; /* select padding works slightly differently to input */
      }

      /* Align submit button to right */
      input[type="submit"] {
        float: right;
      }
      /* Keep floating submit button within the form
       * The + means select the br element immediately following the input
       */
      input[type="submit"] + br {
        clear: both;
      }

      /* Put e.g. inputs with class="block" in their own row */
      .block {
        display: block;
        margin: 0.5em 0;
      }

      /* Example usability CSS */

      /* Indicate required inputs with a * after the first span inside their label
       * Requires adding class="required" to the label or using JavaScript (see below)
       */
      label.required span:first-child::after {
        content: ' *';
        color: #c00;
      }

      /* Indicate current section (CSS Selectors Level 4, may not work) */
      fieldset:focus-within,
      fieldset:focus-within legend {
        background-color: #dee;
      }

      /* Indicate current input */
      input:focus, textarea:focus, select:focus {
        outline: 2px solid #88f;
      }

      /* Example validation CSS */

      /* Add a light red background to visited invalid inputs
       * Inputs are marked as visited using JavaScript (see below)
       */
      input.visited:invalid,
      textarea.invalid {
        background-color: #fffafa;
      }

      /* Hide validation feedback by default */
      span.ok, span.error {
        position: absolute; /* simpler solution: just use display: none; */
        opacity: 0;
        transition: opacity 0.2s; /* fade in/out nicely */
      }

      /* Insert green Unicode check mark before OK feedback */
      span.ok::before {
        content: "\2714";
        color: #0a0;
        margin: 0 0 0 0.5em;
      }
      /* Insert red Unicode cross mark before error feedback */
      span.error::before {
        content: "\2718";
        color: #a00;
        margin: 0 0 0 0.5em;
      }

      /* Show feedback after visited inputs
       * The ~ selects span elements that are siblings of each input element
       */
      input.visited:valid ~ span.ok,
      input.visited:invalid ~ span.error {
        opacity: 1; /* simpler solution: just use display: inline; */
      }

      /* Simple CSS to present data tables a bit more neatly */

      table {
        background-color: #eee;
        padding: 0.5em;
        width: calc(600px + 1em); /* table width/padding works differently to form */
        margin: auto;
      }

      caption {
        font-weight: bold;
        padding: 0.5em;
      }

      th {
        text-align: left;
      }
    </style>
    <!-- This JavaScript is reusable and could be moved to an external file -->
    <script>
      // This line runs the code inside this function after the page is loaded
      // (or place the code at the end of the page, but this is more reliable)
      window.addEventListener("load", function() {

        // Find all input elements with the "required" attribute
        var inputs = document.querySelectorAll(":required");

        // Note this is for..of not for..in unlike e.g. Python
        for (var input of inputs) {
          // Add the "required" class to each containing label element
          // Let the CSS take care of the formatting
          input.parentNode.classList.add("required");
        }

      });

      // This line runs the code inside this function after the page is loaded
      window.addEventListener("load", function() {

        // Make a function to mark inputs as visited when they lose focus
        function markVisited(event) {
          // Add the "visited" class to the element causing the event
          // Let the CSS take care of the formatting
          event.target.classList.add("visited");
        }

        // Make a function to set a custom message from a data-message attribute
        function checkInput(event) {
          // Remove existing custom message
          // You have to clear this first else it will make the element invalid!
          event.target.setCustomValidity("");

          // Recheck validity based on HTML attributes
          if (!event.target.checkValidity()) {
            // Set custom message if input isn't valid
            event.target.setCustomValidity(event.target.dataset.message);
          }
        }

        // Find all input elements
        var inputs = document.getElementsByTagName("input");

        // Note this is for..of not for..in unlike e.g. Python
        for (var input of inputs) {
          // Add an onblur event handler to each input
          input.onblur = markVisited;

          // Set a custom invalid message for inputs with data-message attribute
          if (input.dataset.message) {
            input.oninput = checkInput;
          }
        }

      });
    </script>

<?php

// Read and validate submitted POST data, with default values if missing

// Default to an empty string
$username = $_POST['username'] ?? '';
$first_name = $_POST['first_name'] ?? '';
$last_name = $_POST['last_name'] ?? '';
$age = $_POST['age'] ?? '';
$email_address = $_POST['email_address'] ?? '';
$password = $_POST['password'] ?? '';

// Look for username in $_POST to indicate data entry form was sent
// There could be more elegant, but it keeps things simple
$saving = isset($_POST['username']);

if ($saving) {
  // Example server-side cleaning and validation
  // There is already client-side validation, so the approach here
  // is to prevent invalid data entry, but leave feedback to the client.

  // Bug: Browser support for minlength is incomplete, so the password
  // may not be shown as having an error if part-completed.
  // However, browsers should never submit the form in the first place.

  // Start by assuming everything is OK
  $valid = true;

  // username has a pattern and maxlength attribute
  // Use trim() to clean any leading/trailing spaces
  $username = trim($username);
  // HTML pattern attribute needs surrounding
  // with /^ and $/ to work the same in PHP
  if (!preg_match('/^[A-Za-z0-9]+$/', $username) ||
      strlen($username) > 15) {
    $valid = false;
  }

  // first_name is required and has a maxlength attribute
  // Use trim() to clean any leading/trailing spaces
  $first_name = trim($first_name);
  if (empty($first_name) || strlen($first_name) > 50) {
    $valid = false;
  }

  // last_name is required and has a maxlength attribute
  // Use trim() to clean any leading/trailing spaces
  $last_name = trim($last_name);
  if (empty($last_name) || strlen($last_name) > 50) {
    $valid = false;
  }

  // age is optional but must be a number over 18 if present
  // Use trim() to clean any leading/trailing spaces
  // Use intval() to convert to an integer (or 0)
  $age = trim($age);
  if (!empty($age)) {
    if (intval($age) < 18) {
      $valid = false;
    } else {
      $age = intval($age);
    }
  }

  // email_address must be an email address and has a maxlength attribute
  // Use trim() to clean any leading/trailing spaces
  $email_address = trim($email_address);
  if (!filter_var($email_address, FILTER_VALIDATE_EMAIL) ||
      strlen($email_address) > 50) {
    $valid = false;
  }

  // password is optional but has minlength and maxlength attributes
  // Don't use trim() - leave the password exactly as entered
  if (!empty($password) &&
      (strlen($password) < 8 || strlen($password) > 50)) {
    $valid = false;
  }

  // If the data is valid...
  if ($valid) {

    // SQL INSERT using prepared statement

    // Insert new row into profile table: 6 fields as 6 parameters
    $sql = "INSERT INTO b2p6_profile (username, first_name, last_name, age, email_address, password)" .
      "VALUES (?, ?, ?, ?, ?, ?)";

    // SECURITY: Password storage
    // Storing passwords in plain text is incredibly bad practice!
    // We will fix this in Block 3.

    // Prepare a statement based on the SQL query (or output any error),
    // using mysqli_stmt_prepare() not mysqli_prepare() as it's easier to debug
    $stmt = mysqli_stmt_init($db);
    mysqli_stmt_prepare($stmt, $sql) or die(mysqli_stmt_error($stmt));
    // Bind parameters to the validated data (all strings except integer $age)
    mysqli_stmt_bind_param($stmt, 'sssiss', $username, $first_name, $last_name, $age, $email_address, $password);
    // Execute the statement with its parameters
    mysqli_stmt_execute($stmt) or die(mysqli_stmt_error($stmt));

    // Reset the form input values for entering a new record
    $username = '';
    $first_name = '';
    $last_name = '';
    $age = '';
    $email_address = '';
    $password = '';
  }
}


// Data entry form (similar to earlier validation example)

// Because htmlspecialchars() is quite a lot to type,
// let's create helper functions to use instead
function _x($text) {
  return htmlspecialchars($text);
}
function _e($text) {
  echo _x($text);
}

// Render the form with some extra input attributes:
// value = the value submitted (if saving and invalid)
// class = visited (if saving and invalid) - shows the error span
?>
    <form action="<?php _e($_SERVER['PHP_SELF']) ?>" method="post">
      <fieldset>
        <legend>Enter profile</legend>
        <label class="block">
          <span>User Name</span>
          <input
            value="<?php _e($username); ?>"
            <?php if($saving && !$valid) { echo 'class="visited"'; } ?>
            name="username"
            type="text"
            maxlength="15"
            required
            placeholder="e.g. tt284user"
            pattern="[A-Za-z0-9]+"
            data-message="Please use only letters and numbers."
            aria-describedby="username-error"
          >
          <span class="ok"></span>
          <span id="username-error" class="error" role="alert">
            Please use only letters and numbers.
          </span>
        </label>
        <label class="block">
          <span>First Name</span>
          <input
            value="<?php _e($first_name); ?>"
            <?php if($saving && !$valid) { echo 'class="visited"'; } ?>
            name="first_name"
            type="text"
            maxlength="50"
            required
            aria-describedby="first_name-error"
          >
          <span class="ok"></span>
          <span id="first_name-error" class="error" role="alert">
            This field is required.
          </span>
        </label>
        <label class="block">
          <span>Last Name</span>
          <input
            value="<?php _e($last_name); ?>"
            <?php if($saving && !$valid) { echo 'class="visited"'; } ?>
            name="last_name"
            type="text"
            maxlength="50"
            required
            aria-describedby="last_name-error"
          >
          <span class="ok"></span>
          <span id="last_name-error" class="error" role="alert">
            This field is required.
          </span>
        </label>
        <label class="block">
          <span>Age</span>
          <input
            value="<?php _e($age); ?>"
            <?php if($saving && !$valid) { echo 'class="visited"'; } ?>
            name="age"
            type="number"
            min="18"
            placeholder="(in years, if 18+)"
            aria-describedby="age-error"
          >
          <span class="ok"></span>
          <span id="age-error" class="error" role="alert">
            Please enter a number (if 18 or over).
          </span>
        </label>
        <label class="block">
          <span>Email</span>
          <input
            value="<?php _e($email_address); ?>"
            <?php if($saving && !$valid) { echo 'class="visited"'; } ?>
            name="email_address"
            type="email"
            maxlength="50"
            required
            aria-describedby="email_address-error"
          >
          <span class="ok"></span>
          <span id="email_address-error" class="error" role="alert">
            Please enter a valid email address.
          </span>
        </label>
        <label class="block">
          <span>Password</span>
          <input
            value="<?php _e($password); ?>"
            <?php if($saving && !$valid) { echo 'class="visited"'; } ?>
            name="password"
            type="password"
            minlength="8"
            maxlength="50"
            aria-describedby="password-error"
          >
          <span class="ok"></span>
          <span id="password-error" class="error" role="alert">
            Passwords must be at least 8 characters long.
          </span>
        </label>
        <input type="submit" value="Save">
      </fieldset>
    </form>

<?php


// Search and sort (similar to earlier example)

// Read and filter submitted GET data, with default values if missing

// We will allow sorting on only these field names
// They could be also obtained by examining the database table using SQL
$allow_sorton = ['username', 'first_name', 'last_name', 'age'];
// We will allow sorting by only these directions
$allow_sortby = ['asc', 'desc'];

// For searching, default to an empty string
$search = $_GET['search'] ?? '';

// For ordering, default to the first allowed option
$unsafe_sorton = $_GET['sorton'] ?? $allow_sorton[0];
$unsafe_sortby = $_GET['sortby'] ?? $allow_sortby[0];

// These cannot be SQL escaped so filter them instead
if ($key = array_search($unsafe_sorton, $allow_sorton)) {
  // Value was found in allowed list so use value from list
  // (to reduce the chance of making a coding mistake,
  // we never use the value from $_GET directly)
  $sorton = $allow_sorton[$key];
} else {
  // Value was not found, so just use first allowed value
  // If this should never happen, we could die() here instead
  $sorton = $allow_sorton[0];
}
if ($key = array_search($unsafe_sortby, $allow_sortby)) {
  // Value was found in allowed list so use value from list
  $sortby = $allow_sortby[$key];
} else {
  // Value was not found, so just use first allowed value
  $sortby = $allow_sortby[0];
}

// Output the search form using input value and option selected attribute
// to reflect submitted data
?>
<form action="<?php _e($_SERVER['PHP_SELF']); ?>" method="get">
  <fieldset>
  <legend>Search and sort</legend>
    <label>
      <span style="min-width: 0;">Search for</span>
      <input type="text" name="search" value="<?php _e($search); ?>">
    </label>
    <label>
      <span style="min-width: 0;">sorted by</span>
      <select name="sorton">
<?php foreach($allow_sorton as $option) {
  // Render form with requested option selected
  $selected = ($sorton == $option) ? ' selected' : '';
  echo '<option' . $selected . ' value="' . _x($option) . '">' . _x($option) . '</option>';
} ?></select>

      <select name="sortby">
<?php foreach($allow_sortby as $option) {
  // Render form with requested option selected
  $selected = ($sortby == $option) ? ' selected' : '';
  echo '<option' . $selected . ' value="' . _x($option) . '">' . _x($option) . '</option>';
} ?></select>
    </label>

    <input type="submit" value="Search">
  </fieldset>
</form>

<?

// Search the database

// Select rows from sample sales table
// search is SQL data and will be passed as a parameter 4 times
// sorton and sortby are SQL commands and are added directly
$sql = "SELECT username, first_name, last_name, age, email_address FROM b2p6_profile " .
  "WHERE username LIKE ? OR first_name LIKE ? OR last_name LIKE ? OR email_address LIKE ? " .
  "ORDER BY $sorton $sortby";

// Search for names containing the search term by adding a % (SQL wildcard)
// before and after (note the form is already output so these won't be seen)
$search = '%' . $search . '%';
// A more advanced solution would also handle if $search already contains %

// Prepare a statement based on the SQL query (or output any error),
// using mysqli_stmt_prepare() not mysqli_prepare() as it's easier to debug
$stmt = mysqli_stmt_init($db);
mysqli_stmt_prepare($stmt, $sql) or die(mysqli_stmt_error($stmt));
// Bind 4 string parameters to the value of $search
mysqli_stmt_bind_param($stmt, 'ssss', $search, $search, $search, $search);
// Execute the statement with its parameters
mysqli_stmt_execute($stmt) or die(mysqli_stmt_error($stmt));
// Get a result handle for the executed statement (like we get from mysqli_query())
$result = mysqli_stmt_get_result($stmt);

// Render results as a HTML table

// Get field names from result
$fields = mysqli_fetch_fields($result);
echo '<table><caption>Search results</caption>';
// Output a table heading row with field names
echo '<thead><tr>';
foreach($fields as $field) {
  // Each $field object contains lots of interesting information,
  // but we just want the field name
  echo '<th>' . _x($field->name) . '</th>';
}
echo '</tr></thead>';
// Output table body with row values
echo '<tbody>';
while ($row = mysqli_fetch_assoc($result)) {
  // Start the row
  echo '<tr>';
  // Iterate through the expected fields, retrieving each from the row array by name
  foreach($fields as $field) {
    echo '<td>' . _x($row[$field->name]) . '</td>';
  }
  // End the row
  echo '</tr>';
}
echo '</tbody>';
echo '</table>';

?>

  </body>
</html>