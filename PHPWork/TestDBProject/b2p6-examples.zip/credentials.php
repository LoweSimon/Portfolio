<?php

// Database credentials required by connect.php
$db_user = 'youroucuhere';
$db_password = 'YOURPASSWORDHERE';

// Deliberately don't close PHP tag, to avoid accidental HTML output
// ?>