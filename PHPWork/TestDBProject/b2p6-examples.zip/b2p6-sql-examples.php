<?php
// Allow debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Avoid blank line before opening tag
?><!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8"/>
    <title>Block 2 Part 6 PHP SQL Examples</title>
    <meta name="author" content="Stephen Rice"/>
  </head>
  <body>
    <style>
      /* Simple CSS to present data tables and inputs a bit more neatly */
      table {
        border: 1px solid #aaa;
        margin: 1em 0;
      }
      caption {
        font-weight: bold;
      }
      input {
        display: block;
        margin: 0.5em 0;
      }
    </style>

<?php

// PHP SQL EXAMPLES

// DEPENDS ON:
// connect.php
// Upload and include this file to make a connection to your database.
// credentials.php
// Record your database credentials in this file for use in connect.php.

// ERROR HANDLING:
// If an unexpected error occurs we will simply end the script using die()
// In a real application you might handle errors more elegantly by throwing
// an Exception, logging the error for investigation/monitoring, and showing
// a "friendly" error page instead.


// Reuse code to make a database connection in $db
require 'connect.php';


// SECURITY: Escape text in HTML output
// Any user data (i.e. from GET, POST, database) is escaped using
// htmlspecialchars() to avoid it being interpreted as HTML.
// Essentially to avoid anyone adding malicious JavaScript to the page.
// Do this on output, don't assume data has already been made "safe".

// Because htmlspecialchars() is quite a lot to type,
// let's create helper functions to use instead
function _x($text) {
  return htmlspecialchars($text);
}
function _e($text) {
  echo _x($text);
}


// EXAMPLE: SQL SELECT using raw SQL query

// Select rows from sample sales table
$sql = "SELECT client, date, amount FROM sales";
// Execute the SQL returning a result handle
$result = mysqli_query($db, $sql) or die('Could not execute: ' . _x($sql));

// Fetch each row from the result as an associative array - row by row until there are no more
while ($row = mysqli_fetch_assoc($result)) {
  echo '<p>Row: ';
  // Iterate through the fields in the row as pairs of field name and field value
  foreach($row as $field => $value) {
    echo _x($field) . ': ' . _x($value) . '; ';
  }
  echo '</p>';
}


// SECURITY: Escape or filter data in SQL commands
// Any user data (i.e. from GET, POST, database) is escaped or filtered
// before sending to the database to avoid it being interpreted as SQL.
// Essentially to avoid anyone sending malicious SQL commands to the database.
// One way to do this is using prepared statements...


// EXAMPLE: SQL SELECT using prepared statement

// Select rows from sample sales table
$sql = "SELECT client, date, amount FROM sales";
// Prepare a statement based on the SQL query (or output any error),
// using mysqli_stmt_prepare() not mysqli_prepare() as it's easier to debug
$stmt = mysqli_stmt_init($db);
mysqli_stmt_prepare($stmt, $sql) or die(mysqli_stmt_error($stmt));
// Bind any parameters (none in this case)
// mysqli_stmt_bind_param($stmt, 's...', ...);
// Execute the statement with its parameters
mysqli_stmt_execute($stmt) or die(mysqli_stmt_error($stmt));
// Get a result handle for the executed statement (like we get from mysqli_query())
$result = mysqli_stmt_get_result($stmt);

// Render results as a HTML table

// Get field names from result
$fields = mysqli_fetch_fields($result);
echo '<table><caption>Fetched using prepared statement</caption>';
// Output a table heading row with field names
echo '<thead><tr>';
foreach($fields as $field) {
  // Each $field object contains lots of interesting information,
  // but we just want the field name
  echo '<th>' . _x($field->name) . '</th>';
}
echo '</tr></thead>';
// Output table body with row values
echo '<tbody>';
while ($row = mysqli_fetch_assoc($result)) {
  // Start the row
  echo '<tr>';
  // Iterate through the expected fields, retrieving each from the row array by name
  foreach($fields as $field) {
    echo '<td>' . _x($row[$field->name]) . '</td>';
  }
  // End the row
  echo '</tr>';
}
echo '</tbody>';
echo '</table>';


// EXAMPLE: SQL WHERE / ORDER BY to add row searching and sorting

// Read and filter submitted GET data, with default values if missing

// We will allow sorting on only these field names
// They could be also obtained by examining the database table using SQL
$allow_sorton = ['client', 'date', 'amount'];
// We will allow sorting by only these directions
$allow_sortby = ['asc', 'desc'];

// For searching, default to an empty string
$search = $_GET['search'] ?? '';

// For ordering, default to the first allowed option
$unsafe_sorton = $_GET['sorton'] ?? $allow_sorton[0];
$unsafe_sortby = $_GET['sortby'] ?? $allow_sortby[0];

// These cannot be SQL escaped so filter them instead
if ($key = array_search($unsafe_sorton, $allow_sorton)) {
  // Value was found in allowed list so use value from list
  // (to reduce the chance of making a coding mistake,
  // we never use the value from $_GET directly)
  $sorton = $allow_sorton[$key];
} else {
  // Value was not found, so just use first allowed value
  // If this should never happen, we could die() here instead
  $sorton = $allow_sorton[0];
}
if ($key = array_search($unsafe_sortby, $allow_sortby)) {
  // Value was found in allowed list so use value from list
  $sortby = $allow_sortby[$key];
} else {
  // Value was not found, so just use first allowed value
  $sortby = $allow_sortby[0];
}

// Output the search form using input value and option selected attribute
// to reflect submitted data
?>
<form action="<?php _e($_SERVER['PHP_SELF']); ?>" method="get">
  <fieldset>
  <legend>Search and sort</legend>
    <input type="text" name="search" value="<?php _e($search); ?>">

    <select name="sorton">
<?php foreach($allow_sorton as $option) {
  // Render form with requested option selected
  $selected = ($sorton == $option) ? ' selected' : '';
  echo '<option' . $selected . ' value="' . _x($option) . '">' . _x($option) . '</option>';
} ?></select>

    <select name="sortby">
<?php foreach($allow_sortby as $option) {
  // Render form with requested option selected
  $selected = ($sortby == $option) ? ' selected' : '';
  echo '<option' . $selected . ' value="' . _x($option) . '">' . _x($option) . '</option>';
} ?></select>

    <input type="submit" value="Search">
  </fieldset>
</form>

<?

// Search the database

// Select rows from sample sales table
// search is SQL data and will be passed as a parameter
// sorton and sortby are SQL commands and are added directly
$sql = "SELECT client, date, amount FROM sales WHERE client LIKE ? ORDER BY $sorton $sortby";

// Search for names containing the search term by adding a % (SQL wildcard)
// before and after (note the form is already output so these won't be seen)
$search = '%' . $search . '%';
// A more advanced solution would also handle if $search already contains %

// Prepare a statement based on the SQL query (or output any error),
// using mysqli_stmt_prepare() not mysqli_prepare() as it's easier to debug
$stmt = mysqli_stmt_init($db);
mysqli_stmt_prepare($stmt, $sql) or die(mysqli_stmt_error($stmt));
// Bind a single string parameter to the value of $search
mysqli_stmt_bind_param($stmt, 's', $search);
// Execute the statement with its parameters
mysqli_stmt_execute($stmt) or die(mysqli_stmt_error($stmt));
// Get a result handle for the executed statement (like we get from mysqli_query())
$result = mysqli_stmt_get_result($stmt);

// Render results as a HTML table (same as before)

// Get field names from result
$fields = mysqli_fetch_fields($result);
echo '<table><caption>Search results</caption>';
// Output a table heading row with field names
echo '<thead><tr>';
foreach($fields as $field) {
  // Each $field object contains lots of interesting information,
  // but we just want the field name
  echo '<th>' . _x($field->name) . '</th>';
}
echo '</tr></thead>';
// Output table body with row values
echo '<tbody>';
while ($row = mysqli_fetch_assoc($result)) {
  // Start the row
  echo '<tr>';
  // Iterate through the expected fields, retrieving each from the row array by name
  foreach($fields as $field) {
    echo '<td>' . _x($row[$field->name]) . '</td>';
  }
  // End the row
  echo '</tr>';
}
echo '</tbody>';
echo '</table>';

?>

  </body>
</html>