<?php

// Include this file to make a database connection in $db


// Allow debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Record your database credentials in credentials.php
require 'credentials.php';

// Connect to database running on same server
$db_host = 'localhost';
// TT284 databases are based on username - this may differ if using XAMPP
$db_name = $db_user . '_db';

$db = mysqli_connect($db_host, $db_user, $db_password) or
  die('Unable to connect to host: ' . htmlspecialchars($db_user));

mysqli_select_db($db, $db_name) or
  die('Unable to select database: ' . htmlspecialchars($db_name));


// Deliberately don't close PHP tag, to avoid accidental HTML output
// ?>